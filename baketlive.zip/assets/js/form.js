/*gibbrish function*/
const detect = (s) => {
  let onlyvowels = !/[^aeiou]/.test(s);
  return onlyvowels;
};

//submit data
const submit = $("#submit");
const form = document.querySelector("#client-form");
const offer = $("#offer");
const nameinput = $("#name");
const phone = $("#phone");
const email = $("#email");
const checkinputname = $("i#checkinputname");
const checkinputphone = $("i#checkinputphone");
const checkinputemail = $("i#checkinputemail");
let checkname,
  checkphone,
  checkoffer = false;

//buy link

var buylink = $("#buypdct");

buylink.on("click", () => {
  form.scrollIntoView({ behavior: "smooth" });
});

/*offer input

offer.on('input', e=>{
	val = e.target.value
	if (val != '0'){
		offer.css('border', '3px solid green')
		checkoffer = true
	}else {
		offer.css('border', '3px solid red')
		checkoffer = false	
	}
})*/

/*end offer*/

/*name input*/
function onlyLetters(evt) {
  // Only ASCII charactar in that range allowed
  var ASCIICode = evt.which ? evt.which : evt.keyCode;
  if ((ASCIICode < 65 || ASCIICode > 90) && (ASCIICode < 97 || ASCIICode > 122))
    return false;
  return true;
}
nameinput.on("input", (e) => {
  v = e.target.value;

  /*console.log(gibberish.detect(v.split(' ')[0]), gibberish.detect(v.split(' ')[1]))*/

  if (v.length >= 3 && !detect(v)) {
    checkinputname.removeClass("fa-spinner fa-spin");
    checkinputname.addClass("fa-check-circle");
    checkinputname.css("color", "green");
    checkinputname.prev().css("border-color", "green");
    checkname = true;
  } else {
    checkinputname.addClass("fa-spinner fa-spin");
    checkinputname.prev().css("border-color", "red");
    checkinputname.css("color", "red");
    checkname = false;
  }
});

/*end name input*/

/*phone input*/
function onlyNumberKey(evt) {
  // Only ASCII charactar in that range allowed
  var ASCIICode = evt.which ? evt.which : evt.keyCode;
  if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57)) return false;
  return true;
}

phone.on("input", (e) => {
  v = e.target.value;

  if ((v.slice(0, 2) == "06" || v.slice(0, 2) == "07") && v.length == 10) {
    checkinputphone.removeClass("fa-spinner fa-spin");
    checkinputphone.addClass("fa-check-circle");
    checkinputphone.css("color", "green");
    checkinputphone.prev().css("border-color", "green");
    checkphone = true;
  } else {
    checkinputphone.addClass("fa-spinner fa-spin");
    checkinputphone.prev().css("border-color", "red");
    checkinputphone.css("color", "red");
    checkphone = false;
  }
});
/*end phone input*/

/*email input
email.on('input', e=>{
	val = e.target.value
	var re = /.+@(gmail|yahoo|outlook|)\.com$/;
    if (re.test(val)){
		checkinputemail.removeClass('fa-spinner fa-spin')
		checkinputemail.addClass('fa-check-circle')
		checkinputemail.css('color', 'green')
		checkinputemail.prev().css('border-color','green')
		checkemail = true
	}
	else {
		checkinputemail.addClass('fa-spinner fa-spin')
		checkinputemail.prev().css('border-color','red')
		checkinputemail.css('color', 'red')
		checkemail = false
		

	}
})

end email input*/

const itemname = $(".product-name").text();
const itemprice = $(".product-price").text();

form.addEventListener("input", (e) => {
  if (checkname && checkphone) {
    submit.removeAttr("disabled");
    submit.css({
      background: "#ff5252",
      color: "white",
    });
  } else {
    submit.attr("disabled", "true");
    submit.css({
      background: "black",
      color: "gray",
    });
  }
});

var spinner = $("#loader");
/*
fctr = "";
phone.change((e) => {
  fctr = e.target.value;
});
const dcfctr = (n) => {
  let n2 = n + 2;
  let r = n / n2 / 1.618;
  return r.toString().slice(r.toString.length - 7);
};

let verf = ["668285", "704778"];
promobtn = $(".promocode");
$(".promoinput").on("input", (e) => {
  v = e.target.value;
  console.log(v);
  v.length >= 3
    ? promobtn.attr("disabled", false)
    : promobtn.attr("disabled", true);
});

promobtn.click(() => {
  console.log(dcfctr(fctr));
  if (verf.includes(dcfctr(fctr)) && v == "FIRSTTIME#0BS554218") {
    spinner.css({ display: "flex" });
    setTimeout(function () {
      spinner.hide();
      $(".afterpromo")
        .text(
          `${parseInt($(".itemprice").text()) - 10} DH
			`
        )
        .css({
          color: "green",
        })
        .fadeIn("slow");
    }, 3000);
    $("#promoform").val("1");
    localStorage.setItem("secondtime", "1");
  } else {
    $(".notify").css({ display: "flex" });
    $(".notify").html(`
		<i class="fa fa-warning"></i>
		<p>المرجو التأكد من الرمز</p>
		<p>المرجو إدخال نفس رقم الهاتف</p>
		`);
    setTimeout(() => {
      $(".notify").hide();
    }, 3000);
  }
  console.log(localStorage);
});
*/
const formloader = $(".formloader");
const scriptURL =
  "https://script.google.com/macros/s/AKfycbw1qflOc29fPhhlptIbUGqUDGhuV3KmoaOR4MUsD4OkeACoasQ2GadK/exec";

submit.on("click", (e) => {
  formloader.show();
  e.preventDefault();

  fetch(scriptURL, { method: "POST", body: new FormData(form) })
    .then((response) => {
      

      localStorage.setItem("itemname", itemname);
      localStorage.setItem("itemprice", itemprice);

      form.reset();
      window.location.href = "thanku.html";
    })
    .catch((error) => {
      formloader.hide();
      console.log(error);
      alert("حدث خطأ");
    });
});

/*share form
inputs = $('.inputcontrol>input')
inputicons = $('.inputcontrol>i')
 
sharename = $('.sharename')
sharephone = $('.sharephone')

sharename.on('change', (e)=>{
	e.target.value.length>=3?inputicons[0].classList.add('fa-check'):inputicons[0].classList.add('fa-close')
})


shareform = $('.share')
shareform.on('submit', (e)=>{
	e.preventDefault()
	if (inputs.val()==""){
		console.log('ee')
		inputs.css('border-color', 'red')
		
	} else{
		spinner.css({'display':'flex'})

	}
})
*/
