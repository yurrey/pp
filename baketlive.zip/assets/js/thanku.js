$(".product-name").text(localStorage.getItem("itemname"));
$(".product-price").text(localStorage.getItem("itemprice"));

